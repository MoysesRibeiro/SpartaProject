import variables
print(variables.get_path())