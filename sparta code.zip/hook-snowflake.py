# hook-snowflake.py
# snow_logging is mandatory to get arrow working

hiddenimports = ["snowflake.connector.snow_logging"]