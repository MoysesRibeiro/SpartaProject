x = 1

font1 = "EMprint"
header = f'{font1} {16*x}'
body = f'{font1} {12*x}'


body2 = f'{font1} {9*x}'

ascii = "Consolas 8"
